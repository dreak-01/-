package com.ruanjian.test.action;

import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.apache.struts2.ServletActionContext;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.ruanjian.test.dao.IUserTableDAO;
import com.ruanjian.test.dao.impl.UserTableDAO;
import com.ruanjian.test.model.vo.UserTable;
import com.ruanjian.test.service.IUserTableService;

public class LoginValidateAction extends ActionSupport {

   private UserTable user;

   private IUserTableService userService;


	@Override

	

public void validate() {

	if(user.getUsername()==null || user.getUsername().trim().equals("")){

		addFieldError("user.username", "必须输入用户名");

	}

	if(user.getUserpwd()==null || user.getUserpwd().trim().equals("")){

		addFieldError("user.userpwd", "必须输入密码");

	}

		

}

	/**

	 * @return

	 */

	public String execute() {

       //   ApplicationContext ac= new ClassPathXmlApplicationContext("applicationContext.xml");

           Map session =ActionContext.getContext().getSession();

         boolean validated=false;      //验证成功标识 

         //查询userTable表中的记录  
         UserTable sessionUser=null;

        sessionUser=(UserTable) session.get("user");

         if( sessionUser==null){
     try{
	 // IUserTableDAO userDao=(UserTableDAO)ac.getBean("userTableDAO");

    	  sessionUser=userService.validateUser(user);
          if(sessionUser!=null){

    		  validated=true;      //标识为true表示验证成功通过

              session.put("user", sessionUser);

    	  }

//    	  String hql="from UserTable where username=? and userpwd=? and usertype=?";

//    	  

           }catch(Exception e){

           }

        } else{

        validated=true;

        }

         if(validated)

          {

             //验证成功跳转到main.jsp   

         // resp.sendRedirect("mainServ");

      return SUCCESS;

    }else{

          //resp.sendRedirect("error.jsp");

             //验证失败跳转到error.jsp  

    	HttpServletRequest req=ServletActionContext.getRequest();

    	req.setAttribute("action","用户登录");

    	req.setAttribute("oper_info","用户登录失败");

    	req.setAttribute("next_info","用户登录页");

    	req.setAttribute("next_url","location.href='login.jsp'");

    	return ERROR;

    }


		//return SUCCESS;

	}

	public UserTable getUser() {

		return user;

	}

	public void setUser(UserTable user) {

		this.user = user;

	}

	public IUserTableService getUserService() {

		return userService;

	}

	public void setUserService(IUserTableService userService) {

		this.userService = userService;

	}

}
