package com.ruanjian.test.service;

import com.ruanjian.test.model.vo.UserInfo;

public interface IUserInfoService {
	public UserInfo getUserInfo(int uid);
	
	  public int addOrUpdate(UserInfo userinfo);  
}
