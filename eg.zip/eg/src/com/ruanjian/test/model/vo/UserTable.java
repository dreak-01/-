package com.ruanjian.test.model.vo;

import java.util.HashSet;
import java.util.Set;

/**
 * Usertable entity. @author MyEclipse Persistence Tools
 */

public class UserTable implements java.io.Serializable {

	// Fields
	
	private Integer id;
	private String username;
	private String userpwd;
	private String usertype;
	
   private UserInfo userinfo;
   
   private Set lyTables =new HashSet(0);
	// Constructors    

	/** default constructor */
	public UserTable() {
	}

	/** minimal constructor */
	public UserTable(String username) {
		this.username = username;
	}

	/** full constructor */
	public UserTable(String username, String userpwd, String usertype) {
		this.username = username;
		this.userpwd = userpwd;
		this.usertype = usertype;
	}

	// Property accessors

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getUsername() {
		return this.username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getUserpwd() {
		return this.userpwd;
	}

	public void setUserpwd(String userpwd) {
		this.userpwd = userpwd;
	}

	public String getUsertype() {
		return this.usertype;
	}

	public void setUsertype(String usertype) {
		this.usertype = usertype;    //
	}

	public UserInfo getUserinfo() {
		return userinfo;
	}

	public void setUserinfo(UserInfo userinfo) {
		this.userinfo = userinfo;
	}

	public Set getLyTables() {
		return lyTables;
	}

	public void setLyTables(Set lyTables) {
		this.lyTables = lyTables;
	}

}