package com.ruanjian.test.dao;

import java.util.List;

import com.ruanjian.test.model.vo.LyTable;

public interface ILyTableDAO {
	
  public int getTotalRec();
  public List<LyTable> getLyList(int startR,int reNum);

  public int addOrUpdate(LyTable ly);

  public LyTable getOneLy(int id);//添加留言方法 

  public int delete(LyTable ly); //删除留言  
}
