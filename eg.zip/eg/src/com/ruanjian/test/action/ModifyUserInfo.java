package com.ruanjian.test.action;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.ruanjian.test.model.vo.UserInfo;
import com.ruanjian.test.model.vo.UserTable;
import com.ruanjian.test.service.IUserInfoService;

public class ModifyUserInfo extends ActionSupport {

	private UserInfo userinfo;
    private IUserInfoService infoService;
	/**
	 * @return
	 */
	public String execute() {
		
		//ApplicationContext ac = new ClassPathXmlApplicationContext("applicationContext.xml");

		HttpServletRequest req = ServletActionContext.getRequest();
		
		String uid = req.getParameter("UID");

		String method = req.getMethod();

		Map session = ActionContext.getContext().getSession();

		UserTable user = (UserTable) session.get("user");
		
		boolean validated = false; // 验证成功标识

		if (user == null) {

			return "loginerr";

		}

		if (userinfo == null) {
			
			userinfo = new UserInfo();
		}

		
		//IUserInfoDAO infoDao = (UserInfoDAO) ac.getBean("userInfoDAO");//new UserInfoDAO();   

		if (method.equalsIgnoreCase("get")) {

			userinfo.setUserTable(user);

			// SqlSrvDBConn sqlSrvDB = new SqlSrvDBConn();

			try {

				userinfo = infoService.getUserInfo(Integer.parseInt(uid));
		
				
//				String hql = "from UserInfo where userTable.id=" + uid;
//
//				Query qu = hiberSession.createQuery(hql);
//
//				qu.setMaxResults(1);
//
//				userinfo = (UserInfo) qu.uniqueResult();

				
			} catch (Exception e) {

				e.printStackTrace();
			}

			return SUCCESS;

		} else {
			
			int num = infoService.addOrUpdate(userinfo);
			
//			int id = userinfo.getId();
//
//			int num = 0;
//
//			Transaction tc = hiberSession.beginTransaction();
//
//			if (id == 0) {
//				num = (Integer) hiberSession.save(userinfo);
//				tc.commit();
//			} else {
//				try {
//					hiberSession.update(userinfo);
//					tc.commit();
//					num =1;
//				} catch (Exception e) {
//
//					num = 0;
//				}
//			}

			

			if (num > 0) {
				return "main";
			} else {
				return SUCCESS;
			}

		}
	}

	public UserInfo getUserinfo() {
		return userinfo;
	}

	public void setUserinfo(UserInfo userinfo) {
		this.userinfo = userinfo;
	}

	public IUserInfoService getInfoService() {
		return infoService;
	}

	public void setInfoService(IUserInfoService infoService) {
		this.infoService = infoService;
	}
}