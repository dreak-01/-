package com.ruanjian.test.action;

import java.sql.Date;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.ruanjian.test.model.vo.LyTable;
import com.ruanjian.test.model.vo.UserTable;
import com.ruanjian.test.service.ILyTableService;

public class AddLyAction extends ActionSupport {
	
  private LyTable ly;
  private ILyTableService lyService;
	@Override
	public String execute() throws Exception {
				
	//	ApplicationContext ac= new ClassPathXmlApplicationContext("applicationContext.xml");
	        Map session =ActionContext.getContext().getSession();
	        UserTable user =(UserTable) session.get("user");
	       			  
	        if(user==null){
	           
	           return "loginerr";
	           }      
	        HttpServletRequest req=ServletActionContext.getRequest();
	        String method=req.getMethod();
	        
	        //ILyTableDAO lyService=(LyTableDAO)ac.getBean("lyTableDAO");
	        if(method.equalsIgnoreCase("get")){
	        	String id=req.getParameter("id");
	        	ly= lyService.getOneLy(Integer.parseInt(id));               
	        	return  "modify";
	        }else{
	        	
	        	String type=req.getParameter("type");
	        	if(type!=null && type.equalsIgnoreCase("delete")){
	        	    
	        		String delId=req.getParameter("delId");
	        		if(ly==null){
	        			ly=new LyTable();
	        			
	        		}
	        		
	        		ly.setId(Integer.parseInt(delId));
	        		
	        		lyService.delete(ly);
	        		req.setAttribute("action","删除留言");
	 	 	    	req.setAttribute("oper_info","删除留言成功");
	 	 	    
	        	}else{
	        		 Date lydate = new Date(System.currentTimeMillis());   
	 	 	        ly.setLyDate(lydate);
	 	 	        ly.setUserTable(user);
	 	 	         int num=lyService.addOrUpdate(ly);
	 	 	        if(num>0)
	 	 	        {
	 	 	    //  	HttpServletRequest req=ServletActionContext.getRequest();
	 	 	        	req.setAttribute("action","添加留言");
	 	 	 	    	req.setAttribute("oper_info","添加留言成功");
	 	 	 	  
	 	 	        }
	 	 	        else
	 	 	        {
	 	 	        	req.setAttribute("action","添加留言");
	 	 	 	    	req.setAttribute("oper_info","添加留言失败");
	 	 	 	    	req.setAttribute("next_info","留言列表页");
	 	 	 	    	req.setAttribute("next_url","location.href='liuyan.jsp'");
	 	 	      return ERROR;
	 	 	        }
	 	        }
	        //	req.setAttribute("action","添加留言");
 	 	    	//req.setAttribute("oper_info","添加留言成功");
 	 	    	req.setAttribute("next_info","留言列表页");
 	 	    	req.setAttribute("next_url","location.href='pageLy.action'");
 	 	    
 	 	        	return SUCCESS;
	        	}
	        	
	        

                        
	}
	public LyTable getLy() {
		return ly;
	}
	public void setLy(LyTable ly) {
		this.ly = ly;
	}
	public ILyTableService getLyService() {
		return lyService;
	}
	public void setLyService(ILyTableService lyService) {
		this.lyService = lyService;
	}

}
