package com.ruanjian.test.dao.impl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.ruanjian.test.dao.BaseDAO;
import com.ruanjian.test.dao.ILyTableDAO;
import com.ruanjian.test.factory.HibernateSessionFactory;
import com.ruanjian.test.model.vo.LyTable;

public class LyTableDAO extends BaseDAO implements ILyTableDAO {

	@Override
	public int getTotalRec() {
		 String hql = "from LyTable";
    	 
    	 Query qu = getSession().createQuery(hql);
    	 
    	return qu.list().size();
    	//191软件1王琦 
	}

	@Override
	public List<LyTable> getLyList(int startR, int reNum) {
        String hql = "from LyTable";
    	 Session hiberSession=getSession();
    	
    	 Query qu = hiberSession.createQuery(hql);
    	 hiberSession.flush();
    	 qu.setFirstResult(startR);
    	 qu.setMaxResults(reNum);
    	 

		return qu.list();
	}

	@Override
	public int addOrUpdate(LyTable ly) {
		 Session hiberSession=getSession();
		 hiberSession.clear();
	        Transaction tc=hiberSession.beginTransaction();
	        
	        //int id=ly.getId();
	        
	        int num = 0;
			if (ly.getId() == null || ly.getId()==0) {
				try{
				num = (Integer) hiberSession.save(ly);
				tc.commit();
				} catch (Exception e) {
					e.printStackTrace();
					num = 0;
                   
				}
			} else {
				try {                                           
					hiberSession.update(ly);
					tc.commit();
					num=1;
				} catch (Exception e) {
					e.printStackTrace();
					num = 0;

				}
			}
			HibernateSessionFactory.closeSession();   
		return num;
	}
	@Override
	public LyTable getOneLy(int id) {
		// 添加修改留言方法                                                                                                                            
		 Session hiberSession=getSession();
		 String hql="from LyTable where id="+id;
		 Query qu=hiberSession.createQuery(hql);
		 qu.setMaxResults(1);
		return (LyTable)qu.uniqueResult();
	}

	@Override
	public int delete(LyTable ly) {
		//删除留言
		 Session hiberSession=HibernateSessionFactory.getSession();
		 Transaction tc=hiberSession.beginTransaction();
		 hiberSession.delete(ly);
		 tc.commit();
		// HibernateSessionFactory.closeSession();
		return 1;
	}

}
