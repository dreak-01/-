package com.ruanjian.test.dao;

import com.ruanjian.test.model.vo.UserInfo;

public interface IUserInfoDAO {
	
	  public UserInfo getUserInfo(int uid);
	
	  public int addOrUpdate(UserInfo userinfo);  
}
