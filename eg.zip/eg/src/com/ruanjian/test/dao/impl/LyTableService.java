package com.ruanjian.test.dao.impl;

import java.util.List;

import com.ruanjian.test.dao.ILyTableDAO;
import com.ruanjian.test.model.vo.LyTable;
import com.ruanjian.test.service.ILyTableService;

public class LyTableService implements ILyTableService {
  private ILyTableDAO lyDao;
	@Override
	public int getTotalRec() {
		// TODO Auto-generated method stub
		return lyDao.getTotalRec();
	}

	@Override
	public List<LyTable> getLyList(int startR, int reNum) {
		// TODO Auto-generated method stub
		return lyDao.getLyList(startR, reNum);
	}
	
	@Override
	public int addOrUpdate(LyTable ly) {
		// TODO Auto-generated method stub
		return lyDao.addOrUpdate(ly);
	}

	@Override
	public LyTable getOneLy(int id) {
		// TODO Auto-generated method stub
		return lyDao.getOneLy(id);
	}

	@Override
	public int delete(LyTable ly) {
		// TODO Auto-generated method stub
		return lyDao.delete(ly);
	}

	public ILyTableDAO getLyDao() {
		return lyDao;
	}

	public void setLyDao(ILyTableDAO lyDao) {
		this.lyDao = lyDao;
	}

}
