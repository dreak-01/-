package com.ruanjian.test.dao;

import com.ruanjian.test.model.vo.UserTable;

public interface IUserTableDAO {
	
 public UserTable validateUser(UserTable user);
 		
 public int saveUser(UserTable user);
 

}
