package com.ruanjian.test.util;

import java.text.SimpleDateFormat;
import java.util.Date;

public class DateUtil {
		public static String getCurrentDay(String dateformat){
			SimpleDateFormat dateObject=new SimpleDateFormat(dateformat);
			return dateObject.format(new Date());  //
		}
}
