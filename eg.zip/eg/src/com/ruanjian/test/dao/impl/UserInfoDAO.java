package com.ruanjian.test.dao.impl;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.ruanjian.test.dao.BaseDAO;
import com.ruanjian.test.dao.IUserInfoDAO;
import com.ruanjian.test.factory.HibernateSessionFactory;
import com.ruanjian.test.model.vo.UserInfo;
import com.ruanjian.test.model.vo.UserTable;

public class UserInfoDAO extends BaseDAO implements IUserInfoDAO {

	@Override
	public UserInfo getUserInfo(int uid) {
		
		Session hiberSession = getSession();
		
		
		String hql = "from UserTable where id=" + uid;

		Query qu = hiberSession.createQuery(hql);

		qu.setMaxResults(1);
		
		if(qu.list().size()>0){
			UserTable user = (UserTable)qu.uniqueResult();
			
			return user.getUserinfo();
		}
//		UserInfo userinfo = (UserInfo) qu.uniqueResult();
//		
//		HibernateSessionFactory.closeSession();  

		return null;
		

	}

	@Override
	public int addOrUpdate(UserInfo userinfo) {
		
		Session hiberSession = getSession();

		hiberSession.clear();
		
		int id = userinfo.getId();

		int num = 0;

		Transaction tc = hiberSession.beginTransaction();

		if (id == 0) {
			num = (Integer) hiberSession.save(userinfo);
			tc.commit();
		} else {
			try {
				hiberSession.update(userinfo);
				tc.commit();
				num =1;
			} catch (Exception e) {

				num = 0;
			}
		}
		
		//HibernateSessionFactory.closeSession();
		
		return num;
	}

}
