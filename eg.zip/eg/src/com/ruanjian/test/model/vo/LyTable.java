package com.ruanjian.test.model.vo;

import java.util.Date;

/**
 * LyTable entity. @author MyEclipse Persistence Tools
 */

public class LyTable implements java.io.Serializable {

	// Fields

	private Integer id;
	//private Integer userid;
	private UserTable userTable;
	private String title;
	private String lyContent;
	private Date lyDate;
    //private String username;
	// Constructors

//	public String getUsername() {
//		return username;
//	}
//
//	public void setUsername(String username) {
//		this.username = username;
//	}

	/** default constructor */
	public LyTable() {
	}

	/** full constructor */
	public LyTable(UserTable userTable, String title, String lyContent, Date lyDate) {
		this.userTable = userTable;
		this.title = title;
		this.lyContent = lyContent;
		this.lyDate = lyDate;
	}

	// Property accessors

	public UserTable getUserTable() {
		return userTable;
	}

	public void setUserTable(UserTable userTable) {
		this.userTable = userTable;
	}

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

//	public Integer getUserid() {
//		return this.userid;
//	}
//
//	public void setUserid(Integer userid) {
//		this.userid = userid;
//	}

	public String getTitle() {
		return this.title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getLyContent() {
		return this.lyContent;
	}

	public void setLyContent(String lyContent) {
		this.lyContent = lyContent;
	}

	public Date getLyDate() {
		return this.lyDate;
	}

	public void setLyDate(Date lyDate) {
		this.lyDate = lyDate;
	}

}