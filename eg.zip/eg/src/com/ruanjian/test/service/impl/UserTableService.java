package com.ruanjian.test.service.impl;

import com.ruanjian.test.dao.IUserTableDAO;
import com.ruanjian.test.model.vo.UserTable;
import com.ruanjian.test.service.IUserTableService;

public class UserTableService implements IUserTableService {
   IUserTableDAO userDao;
	public IUserTableDAO getUserDao() {
	return userDao;
}

public void setUserDao(IUserTableDAO userDao) {
	this.userDao = userDao;
}

	@Override
	public UserTable validateUser(UserTable user) {
		
		return userDao.validateUser(user);
	}

	@Override
	public int saveUser(UserTable user) {
		
		return userDao.saveUser(user);
	}

}
