package com.ruanjian.test.model.vo;

import java.util.Date;

/**
 * UserInfo entity. @author MyEclipse Persistence Tools
 */

public class UserInfo implements java.io.Serializable {

	// Fields

	private Integer id;
	private String code;
	private String cnname;      //
	private String sex;
	private Date birDate;
	private String spec;
	private String remarks;
	//private Integer userid;

   private UserTable userTable;
	/** default constructor */
	public UserInfo() {
	}

	/** minimal constructor */
	public UserInfo(String code, String cnname, String sex, Date birDate,
			String spec, UserTable userTable) {
		this.code = code;
		this.cnname = cnname;
		this.sex = sex;
		this.birDate = birDate;
		this.spec = spec;                    //
		this.userTable = userTable;
	}

	/** full constructor */
	public UserInfo(String code, String cnname, String sex, Date birDate,
			String spec, String remarks, UserTable userTable) {
		this.code = code;
		this.cnname = cnname;
		this.sex = sex;
		this.birDate = birDate;
		this.spec = spec;
		this.remarks = remarks;
		this.userTable = userTable;
	}

	// Property accessors

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getCode() {
		return this.code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getCnname() {
		return this.cnname;
	}

	public void setCnname(String cnname) {
		this.cnname = cnname;
	}

	public String getSex() {
		return this.sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public Date getBirDate() {
		return this.birDate;
	}

	public void setBirDate(Date birDate) {
		this.birDate = birDate;
	}                //

	public String getSpec() {
		return this.spec;
	}

	public void setSpec(String spec) {
		this.spec = spec;
	}

	public String getRemarks() {
		return this.remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

//	public Integer getUserid() {
//		return this.userid;
//	}
//
//	public void setUserid(Integer userid) {
//		this.userid = userid;
//	}

	public UserTable getUserTable() {
		return userTable;
	}

	public void setUserTable(UserTable userTable) {
		this.userTable = userTable;
	}

}