package com.ruanjian.test.service.impl;

import com.ruanjian.test.dao.IUserInfoDAO;
import com.ruanjian.test.model.vo.UserInfo;
import com.ruanjian.test.service.IUserInfoService;

public class UserInfoService implements IUserInfoService {
  private IUserInfoDAO infoDao;
	@Override
	public UserInfo getUserInfo(int uid) {
		// TODO Auto-generated method stub
		return infoDao.getUserInfo(uid);
	}

	@Override
	public int addOrUpdate(UserInfo userinfo) {
		// TODO Auto-generated method stub
		return infoDao.addOrUpdate(userinfo);
	}

	public IUserInfoDAO getInfoDao() {
		return infoDao;
	}

	public void setInfoDao(IUserInfoDAO infoDao) {
		this.infoDao = infoDao;
	}

}
