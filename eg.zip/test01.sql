/*
Navicat MySQL Data Transfer

Source Server         : text01
Source Server Version : 50717
Source Host           : localhost:3306
Source Database       : test01

Target Server Type    : MYSQL
Target Server Version : 50717
File Encoding         : 65001

Date: 2021-05-20 17:32:24
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for lytable
-- ----------------------------
DROP TABLE IF EXISTS `lytable`;
CREATE TABLE `lytable` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `lyDate` date NOT NULL,
  `lyContent` varchar(200) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=gbk ROW_FORMAT=COMPACT;

-- ----------------------------
-- Records of lytable
-- ----------------------------
INSERT INTO `lytable` VALUES ('38', '14', '123456', '2020-12-25', '123456');
INSERT INTO `lytable` VALUES ('48', '17', '急哦士大夫', '2021-01-07', '1234');
INSERT INTO `lytable` VALUES ('49', '17', 'kd', '2021-01-07', '124');
INSERT INTO `lytable` VALUES ('50', '17', '22', '2021-01-07', '1111');
INSERT INTO `lytable` VALUES ('51', '17', '256', '2021-01-07', '153');
INSERT INTO `lytable` VALUES ('52', '17', '123', '2021-01-07', '123');
INSERT INTO `lytable` VALUES ('53', '17', '4566', '2021-01-07', '1566');

-- ----------------------------
-- Table structure for userinfo
-- ----------------------------
DROP TABLE IF EXISTS `userinfo`;
CREATE TABLE `userinfo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` char(10) NOT NULL,
  `CNname` char(10) NOT NULL,
  `sex` char(5) NOT NULL,
  `birDate` date NOT NULL,
  `spec` varchar(50) NOT NULL,
  `remarks` varchar(500) DEFAULT NULL,
  `userid` int(11) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=gbk ROW_FORMAT=COMPACT;

-- ----------------------------
-- Records of userinfo
-- ----------------------------
INSERT INTO `userinfo` VALUES ('1', '2019128137', '郑宏恺', 'M', '2020-03-05', '软件1', '444', '17');
INSERT INTO `userinfo` VALUES ('2', '333', '3252', 'M', '2020-12-05', '1522222', '6666666666\r\n6633', '14');
INSERT INTO `userinfo` VALUES ('3', '2019128122', '256', 'M', '2021-01-03', '软件1班', '3366', '19');

-- ----------------------------
-- Table structure for usertable
-- ----------------------------
DROP TABLE IF EXISTS `usertable`;
CREATE TABLE `usertable` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL,
  `userpwd` varchar(20) NOT NULL,
  `usertype` varchar(10) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=gbk ROW_FORMAT=COMPACT;

-- ----------------------------
-- Records of usertable
-- ----------------------------
INSERT INTO `usertable` VALUES ('1', 'wq', '123456', 'admin');
INSERT INTO `usertable` VALUES ('2', 'tom', '123456', 'admin');
INSERT INTO `usertable` VALUES ('3', 'wq01', '123456', 'admin');
INSERT INTO `usertable` VALUES ('4', 'lii', '123456', 'admin');
INSERT INTO `usertable` VALUES ('5', 'tomcat', 'aaa', 'vip');
INSERT INTO `usertable` VALUES ('6', 'tkk', 'null', 'vip');
INSERT INTO `usertable` VALUES ('7', 'ss', 'null', 'admin');
INSERT INTO `usertable` VALUES ('8', 'aa', 'aaa', 'admin');
INSERT INTO `usertable` VALUES ('9', 'qqq', 'aaa', 'guest');
INSERT INTO `usertable` VALUES ('11', 'aaaaa', '111111', 'admin');
INSERT INTO `usertable` VALUES ('12', 'zzz', '222222', 'admin');
INSERT INTO `usertable` VALUES ('13', 'a5', 'aaa', 'admin');
INSERT INTO `usertable` VALUES ('14', 'a2', 'aaa', 'admin');
INSERT INTO `usertable` VALUES ('15', 'a3', 'aaa', 'vip');
INSERT INTO `usertable` VALUES ('16', 'a4', 'aaa', 'admin');
INSERT INTO `usertable` VALUES ('17', 'a1', '123456', 'admin');
INSERT INTO `usertable` VALUES ('18', 'q1', 'aaa', 'admin');
INSERT INTO `usertable` VALUES ('21', 'aaa', '123456', 'admin');
