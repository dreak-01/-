package com.ruanjian.test.action;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.opensymphony.xwork2.ActionSupport;
import com.ruanjian.test.dao.IUserTableDAO;
import com.ruanjian.test.dao.impl.UserTableDAO;
import com.ruanjian.test.model.vo.UserTable;
import com.ruanjian.test.service.IUserTableService;

public class RegUserAction extends ActionSupport {
  private UserTable user;
  
  private IUserTableService userService;
  
	public UserTable getUser() {
	return user;
}
public void setUser(UserTable user) {
	this.user = user;
}
	/**
	 * @return
	 */
	public String execute() {
		ApplicationContext ac= new ClassPathXmlApplicationContext("applicationContext.xml");
		if(user==null){
			return ERROR;
		}
		//IUserTableDAO userDao=(UserTableDAO)ac.getBean("userTableDAO");
			int num=userService.saveUser(user);
		
		
//		//request.setCharacterEncoding("gb2312");			//设置请求编码    
//        String usr=user.getUsername();			//获取提交的用户名
//        String pwd=user.getUserpwd();		//获取提交的密码
//        String urt=user.getUsertype();
//        String sql="insert into userTable(username,userpwd,usertype) values('"+usr+"','"+pwd+"','"+urt+"')";
//        
//       //
//        SqlSrvDBConn SqlSrvDB=new SqlSrvDBConn();
//        int num =SqlSrvDB.executeInsert(sql);	//取得结果集
//       
//       
//        SqlSrvDB.closeStmt();					//关闭语句
//        SqlSrvDB.closeConn();					//关闭连接  
//      //  resp.setCharacterEncoding("gb2312");
//    //   PrintWriter out= resp.getWriter();
        if(num>0)
        {
            
    
          // out.println(" 注册成功，点击<a href=\"login.jsp\">这里</a>到登录界面进行登录。");
     return SUCCESS;
        }
        else
        {
           
        // out.println("注册失败，点击<a href=\"reg.jsp\">这里</a>重新注册。");   
   
        	return ERROR;
        }
		
	}
	public IUserTableService getUserService() {
		return userService;
	}
	public void setUserService(IUserTableService userService) {
		this.userService = userService;
	}
}