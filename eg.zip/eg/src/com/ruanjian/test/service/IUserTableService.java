package com.ruanjian.test.service;

import com.ruanjian.test.model.vo.UserTable;

public interface IUserTableService {
	
 public UserTable validateUser(UserTable user);

 public int saveUser(UserTable user);   
 
}
