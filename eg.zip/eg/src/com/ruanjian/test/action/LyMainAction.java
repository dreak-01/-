package com.ruanjian.test.action;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.ServletActionContext;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.ruanjian.test.dao.ILyTableDAO;
import com.ruanjian.test.dao.impl.LyTableDAO;
import com.ruanjian.test.model.vo.LyTable;
import com.ruanjian.test.model.vo.UserTable;
import com.ruanjian.test.service.ILyTableService;

public class LyMainAction extends ActionSupport {
private ILyTableService lyService;
	/**
	 * @return
	 */
	public String execute() {
		
		//ApplicationContext ac= new ClassPathXmlApplicationContext("applicationContext.xml");
        Map session = ActionContext.getContext().getSession();
        
        UserTable user =(UserTable) session.get("user");
        boolean validated=false;						//验证成功标识
        
        if(user==null){
           //response.sendRedirect("login.jsp");
           return"loginerr";
           }
		
		int pageSize = 5; //用来设置每页显示的记录数
		int totalRec = 0;
		int pageCount = 0;
		int pageNum = 1;
	
        List<LyTable> lyList = new ArrayList<LyTable>();
        
        HttpServletRequest req = ServletActionContext.getRequest();           
        try {
        	//ILyTableDAO lyService=(LyTableDAO)ac.getBean("lyTableDAO");
        	
        	totalRec=lyService.getTotalRec();
//        	 String hql = "from LyTable";
//        	 
//        	 Query qu = HibernateSessionFactory.getSession().createQuery(hql);
//        	 
//        	 List lys = qu.list();
//        	 
//        	 totalRec = lys.size();
//        	 
  			   pageCount = (totalRec % pageSize ==0)?(totalRec/pageSize):(totalRec/pageSize+1);
			   
			   String pageStr = req.getParameter("page");
			   pageNum = (pageStr==null)?1:Integer.parseInt(pageStr);
			   if (pageNum<=0){
				   pageNum = 1;
			   }
		
			   lyList =lyService.getLyList((pageNum-1)*pageSize, pageSize); 
			   
//			   Query que = HibernateSessionFactory.getSession().createQuery(hql);
//			   que.setFirstResult((pageNum-1)*pageSize);
//			   que.setMaxResults(pageSize);
//			   lyList = que.list();
			    
		} catch (Exception e) {
			
			e.printStackTrace();
		}
        
        session.put("myLyList", lyList);
        session.put("pageCount",pageCount);
        session.put("pageNum",pageNum);

		return SUCCESS;
	}
	public ILyTableService getLyService() {
		return lyService;
	}
	public void setLyService(ILyTableService lyService) {
		this.lyService = lyService;
	}
}