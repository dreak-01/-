package com.ruanjian.test.dao.impl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.ruanjian.test.dao.BaseDAO;
import com.ruanjian.test.dao.IUserTableDAO;
import com.ruanjian.test.factory.HibernateSessionFactory;
import com.ruanjian.test.model.vo.UserTable;

public class UserTableDAO extends BaseDAO implements IUserTableDAO {
	@Override
	public UserTable validateUser(UserTable user) {
 
	  String hql="from UserTable where username=? and userpwd=? and usertype=?";
	  
	  Query qu=getSession().createQuery(hql);
	  qu.setParameter(0, user.getUsername());
	  qu.setParameter(1, user.getUserpwd());
	  qu.setParameter(2, user.getUsertype());
	  
	  List users=qu.list();

		  if(users.size()>0){
			  return (UserTable)users.get(0);
		  }
	  
	return null;
	}

	@Override
	public int saveUser(UserTable user) {
		Session session=getSession();
		
		  Transaction tc=session.beginTransaction();
		  int succNum=(Integer)session.save(user);
		
		  tc.commit();
	//	  HibernateSessionFactory.closeSession();   
		  return succNum;
		
	}
}
