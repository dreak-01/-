package com.ruanjian.test.action;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

public class UserLogoutAction extends ActionSupport {

	/**
	 * @return
	 */
	public String execute() {
	Map session =ActionContext.getContext().getSession();
	    session.remove("user");
	  //  System.out.println("!!");
	    
    	HttpServletRequest req=ServletActionContext.getRequest();
    	req.setAttribute("action","注销");
    	req.setAttribute("oper_info","用户注销成功");
    	req.setAttribute("next_info","用户登录页");
    	req.setAttribute("next_url","top.location.href='login.jsp'");
		return SUCCESS;
	}
}